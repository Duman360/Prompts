package yapayzeka.prompt.deposu.yapayzeka_prompt_deposu

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
