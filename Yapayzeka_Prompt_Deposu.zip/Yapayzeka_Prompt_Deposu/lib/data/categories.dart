import 'package:yapayzeka_prompt_deposu/models/category.dart';

final categories = [
  Category(
    id: 'education',
    name: 'Eğitim Yardımcısı',
    icon: '📚',
    description: 'Eğitim ve öğrenme ile ilgili promptlar',
  ),
  Category(
    id: 'language',
    name: 'Dil Öğrenme Yardımcısı',
    icon: '🗣️',
    description: 'Dil öğrenme ve pratik yapma promptları',
  ),
  Category(
    id: 'writing',
    name: 'Yazarlık',
    icon: '✍️',
    description: 'Yaratıcı yazarlık ve içerik oluşturma promptları',
  ),
  Category(
    id: 'health',
    name: 'Sağlık Danışmanı',
    icon: '🏥',
    description: 'Sağlık ve wellness ile ilgili promptlar',
  ),
  Category(
    id: 'social_media',
    name: 'Sosyal Medya Planlayıcısı',
    icon: '📱',
    description: 'Sosyal medya içerik ve strateji promptları',
  ),
  Category(
    id: 'tech_support',
    name: 'Teknik Destek Çözümleri',
    icon: '💻',
    description: 'Teknik sorun çözme promptları',
  ),
];