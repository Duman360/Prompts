import 'package:flutter/material.dart';
import 'package:yapayzeka_prompt_deposu/screens/home_screen.dart';
import 'package:yapayzeka_prompt_deposu/theme/app_theme.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AI Prompt Deposu',
      theme: AppTheme.lightTheme,
      home: const HomeScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}