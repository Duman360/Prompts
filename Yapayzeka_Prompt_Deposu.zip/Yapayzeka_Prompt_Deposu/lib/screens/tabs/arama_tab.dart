import 'package:flutter/material.dart';
import 'package:yapayzeka_prompt_deposu/widgets/search/search_bar.dart';

class AramaTab extends StatelessWidget {
  const AramaTab({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Kategori Ara',
            style: Theme.of(context).textTheme.headlineMedium?.copyWith(
              color: Colors.white,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          const CustomSearchBar(),
          const SizedBox(height: 16),
          Expanded(
            child: Center(
              child: Text(
                'Kategori aramak için yukarıdaki arama çubuğunu kullanın...',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  color: Colors.white.withOpacity(0.7),
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
