import 'package:flutter/material.dart';
import 'package:yapayzeka_prompt_deposu/widgets/cards/feature_card.dart';
import 'package:yapayzeka_prompt_deposu/constants/strings.dart';
import 'package:yapayzeka_prompt_deposu/widgets/cards/svg_logo.dart';

class AnaSayfaTab extends StatelessWidget {
  const AnaSayfaTab({super.key});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final isSmallScreen = constraints.maxWidth < 360;
        // Logo boyutunu büyüt
        final logoSize = constraints.maxWidth * 0.3; // %30'a çıkarıldı
        final maxLogoSize = constraints.maxHeight * 0.3; // Maximum boyut artırıldı
        final minLogoSize = constraints.maxHeight * 0.2; // Minimum boyut artırıldı
        final adaptiveLogoSize = logoSize.clamp(minLogoSize, maxLogoSize);

        return Padding(
          padding: EdgeInsets.symmetric(
            horizontal: constraints.maxWidth * 0.04,
            vertical: constraints.maxHeight * 0.02,
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              // SvgLogoWidget kullanılırken adaptiveLogoSize parametresi eklendi
              SvgLogoWidget(size: adaptiveLogoSize),
          SizedBox(height: constraints.maxHeight * 0.04),
          // Açıklama
          Padding(
            padding: EdgeInsets.symmetric(horizontal: constraints.maxWidth * 0.08),
              child: Text(
                AppStrings.appTitle,
                style: Theme.of(context).textTheme.headlineLarge?.copyWith(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: isSmallScreen ? 14 : 16,
                  shadows: [
                    Shadow(
                      color: Colors.black.withOpacity(0.3),
                      offset: const Offset(0, 2),
                      blurRadius: 4,
                    ),
                  ],
                ),
                textAlign: TextAlign.center,
              ),
              ),
              SizedBox(height: constraints.maxHeight * 0.01),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: constraints.maxWidth * 0.0),
                child: Text(
                  AppStrings.appDescription,
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    color: Colors.white.withOpacity(0.9),
                    fontSize: isSmallScreen ? 10 : 14,
                    height: 1.4,
                    shadows: [
                      Shadow(
                        color: Colors.black.withOpacity(0.3),
                        offset: const Offset(0, 2),
                        blurRadius: 2,
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: constraints.maxHeight * 0.03),
              // Özellik Kartları Grid'i
              GridView.count(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisCount: 2,
                childAspectRatio: 1,
                mainAxisSpacing: constraints.maxHeight * 0.015,
                crossAxisSpacing: constraints.maxWidth * 0.03,
                children: const [
                  FeatureCard(
                    icon: Icons.category_sharp,
                    title: '100+ Kategori',
                    description: 'Konulara ve kullanım alanlarına göre düzenlenmiş promptlar',
                  ),
                  FeatureCard(
                    icon: Icons.format_quote_sharp,
                    title: '5000+ Prompt',
                    description: 'Özenle hazırlanmış geniş prompt koleksiyonuna erişin',
                  ),
                  FeatureCard(
                    icon: Icons.favorite,
                    title: 'Favoriler',
                    description: 'Beğendiğiniz promptları favorilere kaydedin',
                  ),
                  FeatureCard(
                    icon: Icons.saved_search_sharp,
                    title: 'Kaydet',
                    description: 'Kullandığınız promptları takip edin',
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}
