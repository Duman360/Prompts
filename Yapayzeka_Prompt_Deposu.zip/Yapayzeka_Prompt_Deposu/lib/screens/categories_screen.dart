import 'package:flutter/material.dart';
import '../data/categories.dart';
import 'prompts_screen.dart';

class CategoriesScreen extends StatelessWidget {
  const CategoriesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('AI Prompt Kategorileri'),
      ),
      body: ListView.builder(
        itemCount: categories.length,
        itemBuilder: (context, index) {
          final category = categories[index];
          return ListTile(
            leading: Text(
              category.icon,
              style: TextStyle(fontSize: 24),
            ),
            title: Text(category.name),
            subtitle: Text(category.description),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => PromptsScreen(category: category),
              ),
            ),
          );
        },
      ),
    );
  }
}