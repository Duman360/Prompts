import 'package:flutter/material.dart';
import 'package:yapayzeka_prompt_deposu/widgets/navigation/bottom_nav_bar.dart';
import 'package:yapayzeka_prompt_deposu/screens/tabs/ana_sayfa_tab.dart';
import 'package:yapayzeka_prompt_deposu/screens/tabs/kategoriler_tab.dart';
import 'package:yapayzeka_prompt_deposu/screens/tabs/arama_tab.dart';
import 'package:yapayzeka_prompt_deposu/screens/tabs/favoriler_tab.dart';
import 'package:yapayzeka_prompt_deposu/screens/tabs/gecmis_tab.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;

  final List<Widget> _screens = [
    const AnaSayfaTab(),
    const KategorilerTab(),
    // Artık AramaTab'a categories parametresi geçmiyoruz
    const AramaTab(),
    const FavorilerTab(),
    const GecmisTab(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Colors.blue, Colors.purple],
          ),
        ),
        child: SafeArea(
          child: _screens[_selectedIndex],
        ),
      ),
      bottomNavigationBar: CustomBottomNavBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
      ),
    );
  }
}
