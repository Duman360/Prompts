import 'package:flutter/material.dart';
import 'package:flutter/services.dart'; // Kopyalama için gerekli
import '../models/category.dart';
import '../data/prompts.dart';

class PromptsScreen extends StatefulWidget {
  final Category category;

  const PromptsScreen({super.key, required this.category});

  @override
  State<PromptsScreen> createState() => _PromptsScreenState();
}

class _PromptsScreenState extends State<PromptsScreen> {
  final Set<String> _favoritePromptIds = {};
  final Set<String> _usedPromptIds = {};

  void _toggleFavorite(String promptId) {
    setState(() {
      if (_favoritePromptIds.contains(promptId)) {
        _favoritePromptIds.remove(promptId);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Favorilerden çıkarıldı')),
        );
      } else {
        _favoritePromptIds.add(promptId);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Favorilere eklendi')),
        );
      }
    });
  }

  void _markAsUsed(String promptId) {
    setState(() {
      _usedPromptIds.add(promptId);
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Kullanılanlara kaydedildi')),
    );
  }

  void _copyPrompt(String content) {
    Clipboard.setData(ClipboardData(text: content));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Kopyalandı')),
    );
  }

  void _sharePrompt(String content) {
    // Burada paylaşım fonksiyonu entegre edebilirsiniz.
    // Şimdilik sadece örnek bir geri bildirim gösteriyoruz.
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Paylaşım özelliği henüz eklenmedi')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final categoryPrompts = prompts.where(
          (prompt) => prompt.categoryId == widget.category.id,
    ).toList();

    return Scaffold(
      // AppBar beyaz zemin, siyah yazı:
      appBar: AppBar(
        title: Text('${widget.category.name} Promptları'),
        backgroundColor:Colors.transparent,
        foregroundColor: Colors.white,
      ),
      backgroundColor: Colors.blue,
      body: Column(
        children: [
          // Üstte beyaz alan, altta gradient
          Expanded(
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Colors.blue, Colors.purple],
                ),
              ),
              child: SafeArea(
                top: false, // AppBar zaten beyaz zemin
                child: ListView.builder(
                  itemCount: categoryPrompts.length,
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.all(8.0),
                  itemBuilder: (context, index) {
                    final prompt = categoryPrompts[index];
                    final isFavorite = _favoritePromptIds.contains(prompt.id);

                    return Card(
                      color: Colors.white.withOpacity(0.1),
                      margin: const EdgeInsets.symmetric(vertical: 8),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                      elevation: 0,
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              prompt.title,
                              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                shadows: [
                                  Shadow(
                                    color: Colors.black.withOpacity(0.3),
                                    offset: const Offset(0, 2),
                                    blurRadius: 4,
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              prompt.content,
                              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                color: Colors.white.withOpacity(0.9),
                                height: 1.4,
                              ),
                            ),
                            const SizedBox(height: 12),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                IconButton(
                                  icon: Icon(
                                    isFavorite ? Icons.favorite : Icons.favorite_border,
                                    color: isFavorite ? Colors.redAccent : Colors.white,
                                  ),
                                  onPressed: () => _toggleFavorite(prompt.id),
                                  tooltip: 'Favorilere ekle/çıkar',
                                ),
                                IconButton(
                                  icon: const Icon(Icons.save, color: Colors.white),
                                  onPressed: () => _markAsUsed(prompt.id),
                                  tooltip: 'Kullanılanlara kaydet',
                                ),
                                IconButton(
                                  icon: const Icon(Icons.copy, color: Colors.white),
                                  onPressed: () => _copyPrompt(prompt.content),
                                  tooltip: 'Kopyala',
                                ),
                                IconButton(
                                  icon: const Icon(Icons.share, color: Colors.white),
                                  onPressed: () => _sharePrompt(prompt.content),
                                  tooltip: 'Paylaş',
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
