class AppStrings {
  static const String appTitle ="Yapay Zeka(AI) Prompt Deposu";
  static const String appDescription =
      'Yapay zeka konuşmalarınız için mükemmel promptları keşfedin ve kaydedin. '
      '100\'den fazla kategoride 5.000\'den fazla özenle hazırlanmış prompta erişin.';
}