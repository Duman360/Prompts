class Prompt {
  final String id;
  final String title;
  final String content;
  final String categoryId;

  const Prompt({
    required this.id,
    required this.title,
    required this.content,
    required this.categoryId,
  });
}