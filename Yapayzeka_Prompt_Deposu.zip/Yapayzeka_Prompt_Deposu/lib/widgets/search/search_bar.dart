import 'package:flutter/material.dart';
import 'package:yapayzeka_prompt_deposu/data/categories.dart';
import 'package:yapayzeka_prompt_deposu/models/category.dart';
import 'package:yapayzeka_prompt_deposu/screens/prompts_screen.dart';

class CustomSearchBar extends StatefulWidget {
  const CustomSearchBar({super.key});

  @override
  State<CustomSearchBar> createState() => _CustomSearchBarState();
}

class _CustomSearchBarState extends State<CustomSearchBar> {
  List<Category> filteredCategories = [];
  String query = '';

  void _updateSearch(String value) {
    setState(() {
      query = value;
      filteredCategories = categories
          .where((cat) => cat.name.toLowerCase().contains(query.toLowerCase()))
          .toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    final double maxListHeight = MediaQuery.of(context).size.height * 0.4;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.2),
            borderRadius: BorderRadius.circular(12),
          ),
          child: TextField(
            style: const TextStyle(color: Colors.white),
            onChanged: _updateSearch,
            cursorColor: Colors.white.withOpacity(0.5),
            decoration: InputDecoration(
              hintText: 'Kategori ara...',
              hintStyle: TextStyle(color: Colors.white.withOpacity(0.5)),
              prefixIcon: Icon(
                Icons.manage_search,
                color: Colors.white.withOpacity(0.5),
              ),
              border: InputBorder.none,
            ),
          ),
        ),
        const SizedBox(height: 6),
        if (query.isNotEmpty && filteredCategories.isNotEmpty)
          LimitedBox(
            maxHeight: maxListHeight,
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 1),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: ListView.builder(
                shrinkWrap: true,
                physics: const BouncingScrollPhysics(),
                itemCount: filteredCategories.length > 4 ? 4 : filteredCategories.length,
                itemBuilder: (context, index) {
                  final category = filteredCategories[index];
                  return ListTile(
                    title: Text(category.name),
                    trailing: const Icon(Icons.chevron_right_outlined),
                    textColor: Colors.white,
                    iconColor: Colors.white,
                    onTap: () {
                      // Eskiden CategoryDetailScreen'e gidiyordu, artık PromptsScreen'e gidecek
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => PromptsScreen(category: category),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ),
      ],
    );
  }
}
