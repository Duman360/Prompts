import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class SvgLogoWidget extends StatelessWidget {
  final double size; // Dışarıdan boyut almak için parametre ekledik

  const SvgLogoWidget({super.key, required this.size});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size, // Dinamik boyut kullanımı
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: Colors.white.withOpacity(0.0),
      ),
      child: SvgPicture.asset(
        'assets/images/ai_logo.svg',
        fit: BoxFit.contain,
      ),
    );
  }
}
